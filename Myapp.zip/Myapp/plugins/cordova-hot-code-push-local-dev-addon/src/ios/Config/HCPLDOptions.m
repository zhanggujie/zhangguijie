//
//  HCPLDOptions.m
//  TestCHCP
//
//  Created by Nikolay Demyankov on 04.11.15.
//
//

#import "HCPLDOptions.h"

@implementation HCPLDOptions

- (instancetype)init {
    self = [super init];
    if (self) {
        self.enabled = NO;
    }
    
    return self;
}

@end
